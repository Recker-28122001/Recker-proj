name= input()
output=""

for i in name:
    if i in ["A","E","I","O","U","a","e","i","o","u"]:
        output+=""
    else:
        output+=i


print(output)
