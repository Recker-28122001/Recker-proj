name = input("Enter camel case")
res=""
x=""
for i in name:
    if(i.isupper()):
        res=res+"*"+i
    else:
        res=res+i
        
splitword= res.split("*")
for n in splitword:
    x=x+n.lower()+"_"


print(x[:-1])





        


