amountdue=50

while amountdue>0:
    print("Amount due: ", amountdue)
    coin= int(input("Input coin: "))

    if coin in [25,5,10]:
        amountdue -= coin

change= abs(amountdue)
print("Change owed: ", change)
    
