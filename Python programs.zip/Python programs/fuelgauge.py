def main():
    while True:
        try:
            x=input("Fraction:")
            a= int(x[0])
            b= int(x[2])
            z=value(a,b)
            print(z)
            break
        except ValueError:
            pass
        except ZeroDivisionError:
            pass
    
   

def value(x,y):
    if (x/y)*100<1:
        return 'E'
    elif (x/y)*100>99:
        return 'F'
    else:
        return str(int((x/y)*100))+"%"
      
        
        

main()



