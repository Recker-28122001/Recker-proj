def main():
    plate = input("Plate: ")
    if isvalid(plate):
        print("Valid")
    else:
        print("Invalid")


def isvalid(x):
    
    if len(x)<2 or len(x)>6:#To check range lies btw 1 and 6 characters
        return False

    if x[0].isalpha()== False or x[1].isalpha()==False:
        return False#To check 1st and 2nd chars are not digits

    i=0
    
    while i<len(x):
        if x[i].isalpha()==False: 
            if x[i]=='0':#To check 1st possible digit is not 0 
                return False 
            else:
                break

        i+=1#To stop eternal while loop


    j=0
    while j<len(x)-1:#To make sure AAA22A is invalid but AAA222 is not
            if x[j].isalpha()==False and x[j+1].isalpha()==True:
                return False
            j+=1


    for c in x: #To avoid these signs
        if c in [' ', '!', '?', '.']:
            return False



    return True


main()

